package com.example.komalshahi.bookstore;

import android.app.AlertDialog;
import android.app.LoaderManager;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.komalshahi.bookstore.data.BookContract;
import com.example.komalshahi.bookstore.data.BookDbHelper;

public class EditorActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor>{

    private EditText mNameEditText;
    private EditText mPriceEditText;
    private TextView mQuantityText;
    private EditText mSupplierNameEditText;
    private EditText mSupplierNumberEditText;
    private Uri mCurrentBookUri;
    private static final int EXISTING_PET_LOADER = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editor_activity);

        Intent intent=getIntent();
        mCurrentBookUri=intent.getData();

        if (mCurrentBookUri == null) {
            setTitle(R.string.editor_activity_title_new_book);
        } else {
            setTitle(getString(R.string.editor_activity_title_edit_book));
            getLoaderManager().initLoader(EXISTING_PET_LOADER, null, this);
        }
        invalidateOptionsMenu();

        mNameEditText=(EditText) findViewById(R.id.edit_book_name);
        mPriceEditText=(EditText) findViewById(R.id.edit_price);
        mQuantityText=(TextView) findViewById(R.id.quantity_text_view);
        mSupplierNameEditText=(EditText) findViewById(R.id.edit_supplier_name);
        mSupplierNumberEditText=(EditText) findViewById(R.id.edit_supplier_number);
    }
    int quantity =Integer.parseInt( mQuantityText.getText().toString().trim());
     public void increment(View view) {
           if (quantity == 100){
               Toast.makeText(this,"You cannot order more than hundred books",Toast.LENGTH_SHORT).show();
               return;
           }
           quantity=quantity+1;
           display(quantity);
       }

       public void decrement(View view) {
           if (quantity == 1){
               Toast.makeText(this,"You cannot have less than one book",Toast.LENGTH_SHORT).show();
               return;
           }
           quantity=quantity-1;
           display(quantity);
       }

    private
    void display(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view);
        quantityTextView.setText("" + number);

    }


    public void dail(View view) {
         String suppliernumber = mSupplierNumberEditText.getText().toString().trim();
        Intent intent=new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:" + suppliernumber));
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    private void saveBook() {
        String nameString=mNameEditText.getText().toString().trim();
        String priceString=mPriceEditText.getText().toString().trim();
        String suppliernameString=mSupplierNameEditText.getText().toString().trim();
        String suppliernumberString=mSupplierNumberEditText.getText().toString().trim();

        if (mCurrentBookUri == null && TextUtils.isEmpty(nameString) || TextUtils.isEmpty(priceString) || TextUtils.isEmpty(suppliernameString) || TextUtils.isEmpty(suppliernumberString) || quantity==0) {
            return;
        }


        ContentValues values=new ContentValues();

        values.put(BookContract.BookEntry.COLUMN_BOOK_NAME, nameString);
        int price=0;
        if (!TextUtils.isEmpty(priceString)) {
            price=Integer.parseInt(priceString);
        }

        values.put(BookContract.BookEntry.COLUMN_PRICE, price);
        values.put(BookContract.BookEntry.COLUMN_QUANTITY,quantity);
        values.put(BookContract.BookEntry.COLUMN_SUPPLIER_NAME, suppliernameString);
        long number=0;
        if (!TextUtils.isEmpty(suppliernumberString)) {
            number=Long.parseLong(suppliernumberString);
        }

        values.put(BookContract.BookEntry.COLUMN_SUPPLIER_NUMBER, number);
        if (mCurrentBookUri == null) {
            Uri newUri=getContentResolver().insert(BookContract.BookEntry.CONTENT_URI, values);
            if (newUri == null) {
                // If the new content URI is null, then there was an error with insertion.
                Toast.makeText(this, getString(R.string.editor_insert_book_failed),
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, getString(R.string.editor_insert_book_successful),
                        Toast.LENGTH_SHORT).show();
            }
        }else{
                int rowsAffected=getContentResolver().update(mCurrentBookUri, values, null, null);
                if (rowsAffected == 0) {
                    Toast.makeText(this, getString(R.string.editor_update_book_failed),
                            Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, getString(R.string.editor_update_book_successful),
                            Toast.LENGTH_SHORT).show();
                }
            }

        }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu options from the res/menu/menu_editor.xml file.
        // This adds menu items to the app bar.
        getMenuInflater().inflate(R.menu.menu_editor, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // User clicked on a menu option in the app bar overflow menu
        switch (item.getItemId()) {
            // Respond to a click on the "Save" menu option
            case R.id.action_save:
                saveBook();
                finish();
                return true;

            case R.id.action_delete:
                showDeleteConfirmationDialog();
                return true;
            // Respond to a click on the "Up" arrow button in the app bar
            case android.R.id.home:
                // Navigate back to parent activity (CatalogActivity)
                NavUtils.navigateUpFromSameTask(this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private
    void showDeleteConfirmationDialog() {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setMessage(R.string.delete_dialog_msg);
        builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
            public
            void onClick(DialogInterface dialog, int id) {
                deleteBook();
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public
            void onClick(DialogInterface dialog, int id) {
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();
    }

    private
    void deleteBook() {
        if (mCurrentBookUri != null) {
            int rowsDeleted=getContentResolver().delete(mCurrentBookUri, null, null);
            if (rowsDeleted == 0) {
                Toast.makeText(this, getString(R.string.editor_delete_book_failed),
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, getString(R.string.editor_delete_book_successful),
                        Toast.LENGTH_SHORT).show();
            }
            finish();
        }
    }

    @Override
    public
    Loader<Cursor> onCreateLoader(int id, Bundle args) {
        String[] projection={
                BookContract.BookEntry._ID,
                BookContract.BookEntry.COLUMN_BOOK_NAME,
                BookContract.BookEntry.COLUMN_PRICE,
                BookContract.BookEntry.COLUMN_QUANTITY,
                BookContract.BookEntry.COLUMN_SUPPLIER_NAME,
                BookContract.BookEntry.COLUMN_SUPPLIER_NUMBER};
        return new CursorLoader(this,
                mCurrentBookUri,
                projection,
                null,
                null,
                null);

    }

    @Override
    public
    void onLoadFinished(Loader <Cursor> loader, Cursor cursor) {
        if (cursor == null || cursor.getCount() < 1) {
            return;
        }
        if (cursor.moveToFirst()) {
            int nameColumnIndex=cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_NAME);
            int priceColumnIndex=cursor.getColumnIndex(BookContract.BookEntry.COLUMN_PRICE);
            int quantityColumnIndex=cursor.getColumnIndex(BookContract.BookEntry.COLUMN_QUANTITY);
            int suppliernameColumnIndex=cursor.getColumnIndex(BookContract.BookEntry.COLUMN_SUPPLIER_NAME);
            int suppliernumberColumnIndex=cursor.getColumnIndex(BookContract.BookEntry.COLUMN_SUPPLIER_NUMBER);


            String name=cursor.getString(nameColumnIndex);
            int price=cursor.getInt(priceColumnIndex);
            int mquantity=cursor.getInt(quantityColumnIndex);
            String suppliername=cursor.getString(suppliernameColumnIndex);
            long suppliernumber=cursor.getLong(suppliernumberColumnIndex);

            mNameEditText.setText(name);
            mPriceEditText.setText(Integer.toString(price));
            mQuantityText.setText(Integer.toString(mquantity));
            mSupplierNameEditText.setText(suppliername);
            mSupplierNumberEditText.setText(Long.toString(suppliernumber));


        }
        }

    @Override
    public
    void onLoaderReset(Loader <Cursor> loader) {
        mNameEditText.setText("");
        mPriceEditText.setText("");
        mQuantityText.setText("");
        mSupplierNameEditText.setText("");
        mSupplierNumberEditText.setText("");

    }
    @Override
    public
    boolean onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        if (mCurrentBookUri == null) {
            MenuItem menuItem=menu.findItem(R.id.action_delete);
            menuItem.setVisible(false);
        }
        return true;
    }

}
