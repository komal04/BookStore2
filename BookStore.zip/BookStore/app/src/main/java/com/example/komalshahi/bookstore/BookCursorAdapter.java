package com.example.komalshahi.bookstore;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import com.example.komalshahi.bookstore.data.BookContract;

public class BookCursorAdapter extends CursorAdapter {
    public
    BookCursorAdapter(Context context,Cursor c) {
        super(context,c);
    }

    @Override
    public
    View newView(Context context,Cursor cursor,ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);

    }

    @Override
    public
    void bindView(View view,Context context,Cursor cursor) {
        TextView nameTextView = (TextView) view.findViewById(R.id.name);
        TextView summaryTextView = (TextView) view.findViewById(R.id.summary);
        TextView priceTextView = (TextView) view.findViewById(R.id.productprice);
        TextView quantityTextView = (TextView) view.findViewById(R.id.productquantity);
        int nameColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_NAME);
        int supplierColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_SUPPLIER_NAME);
        int priceColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_PRICE);
        int quantityColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_QUANTITY);
        String bookName = cursor.getString(nameColumnIndex);
        String bookSupplier = cursor.getString(supplierColumnIndex);
        int bookprice = cursor.getInt(priceColumnIndex);
        int bookquantity = cursor.getInt(quantityColumnIndex);
        nameTextView.setText(bookName);
        summaryTextView.setText(bookSupplier);
        priceTextView.setText(Integer.toString(bookprice));
        quantityTextView.setText(Integer.toString(bookquantity) );

    }
}
